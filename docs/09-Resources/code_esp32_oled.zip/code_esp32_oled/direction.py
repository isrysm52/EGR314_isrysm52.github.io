from machine import Pin, I2C
import time

# Shared state read by `main.py`.
state = None
last_press = 0

CAMERA_Pin = 9
FORWARD_Pin = 8
BACKWARD_Pin = 46
LEFT_Pin = 18
RIGHT_Pin = 3
UP_Pin = 9
DOWN_Pin = 10


# Create Pin objects so we can query all buttons from any handler.
pins = {
    "C": Pin(CAMERA_Pin, Pin.IN, Pin.PULL_UP),
    "F": Pin(FORWARD_Pin, Pin.IN, Pin.PULL_UP),
    "B": Pin(BACKWARD_Pin, Pin.IN, Pin.PULL_UP),
    "L": Pin(LEFT_Pin, Pin.IN, Pin.PULL_UP),
    "R": Pin(RIGHT_Pin, Pin.IN, Pin.PULL_UP),
    "U": Pin(UP_Pin, Pin.IN, Pin.PULL_UP),
    "D": Pin(DOWN_Pin, Pin.IN, Pin.PULL_UP),
}

def make_handler(label):
    def handler(pin):
        # Called on both press (value==0) and release (value==1).
        global state, last_press
        now = time.ticks_ms()
        # simple debounce
        if time.ticks_diff(now, last_press) < 50:
            return

        if pin.value() == 0:
            # button pressed -> set state to this direction
            state = label
        else:
            # button released -> if any other button is still pressed, use that
            for lbl, p in pins.items():
                if p.value() == 0:
                    state = lbl
                    break
            else:
                # no buttons pressed -> clear state (show star)
                state = None

        last_press = now

    return handler

# Attach IRQs for both falling (press) and rising (release).
for lbl, p in pins.items():
    p.irq(trigger=Pin.IRQ_FALLING | Pin.IRQ_RISING, handler=make_handler(lbl))