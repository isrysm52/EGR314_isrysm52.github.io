import my_oled
import time
import asyncio
from machine import UART
import direction
from machine import Pin, I2C
import micropython

# Use the `state` from the `direction` module so button IRQs update it.
global previous_state
previous_state = None

#define arrays
global msg
global data
global complete
global j

msg = bytearray(65)
data = bytearray(65)
complete = 0
j = 0


led_red = Pin(45, Pin.OUT) 
LED_green = Pin(48, Pin.OUT)
Value = 0

#txd0_pin = Pin(37, Pin.OUT)
#rxd0_pin = Pin(36, Pin.IN)
uart = UART(1, baudrate=9600, tx=43, rx=42)   #tx was 43 rx was 42  use tx41 and rx40 for 8pin making each #2 in 8pin
uart.init(9600, bits=8, parity=None, stop=1,flow=0) # init with given parameters

    
    
async def receiver():
    buffer = bytearray()
    collecting = False

    while True:
        if uart.any():
            data = uart.read()
            if not data:
                continue

            for b in data:

                # START "AZ"
                if not collecting:
                    if b == ord('A'):
                        buffer = bytearray()
                        buffer.append(b)
                        collecting = True
                    continue

                buffer.append(b)

                # STOP "YB"
                if len(buffer) >= 2 and buffer[-2:] == b'YB':

                    try:
                        packet = buffer.decode('utf-8')
                        print("RAW PACKET:", packet)

                        # remove AZ and YB
                        core = packet[2:-2]
                        
                        #print("RAW CORE:", core)
                        #print("PART COUNT:", len(parts))

                        if len(core) >= 3:  # minimum: sender, receiver, type
                            sender = core[0]
                            receiver = core[1]
                            ptype = core[2]
                            info = core[3:] if len(core) > 3 else ""   # allows extra data safely
                            
                            
                        if receiver == 'A' and ptype in ['5', '6', '7']:
                            print("FROM:", sender)
                            print("TO:", receiver)
                            print("TYPE:", ptype)
                            print("INFO:", info)

                            my_oled.oled.fill(0)
                            my_oled.oled.text("FROM:" + sender, 0, 0)
                            my_oled.oled.text("TYPE:" + ptype, 0, 10)
                            my_oled.oled.text(info[:16], 0, 20)
                            my_oled.oled.text(info[16:32], 0, 30)
                            my_oled.oled.show()
                            
                            
                        if receiver != 'A' and receiver in ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']:
                            uart.write(packet)
                        
                        
                        
                        else:
                            print("IGNORED PACKET")
                            

                
                    except Exception as e:
                        print("Parse error:", e)

                    collecting = False
                    buffer = bytearray()

        await asyncio.sleep(0)


    
async def main():
    global previous_state, complete, j, data

    while True:
        led_red.value(0)  # Turn off the red LED
#         Value = Pin(42, Pin.IN)
#         LED_green.value(Value)
        
#         my_oled.oled.fill(0)
#         my_oled.oled.text("TEST", 0, 0)
#         my_oled.oled.show()
        print("STANDBY")
        

        await asyncio.sleep(0.01)
        current = direction.state #OG
        # Only redraw when the direction state actually changes
        if current != previous_state:
            if current == "F":
                print("FORWARD")
#                 my_oled.oled.fill(0)
#                 my_oled.graphics.fill_circle(64,32,8,1)
#                 my_oled.graphics.fill_triangle(54,24, 74,24, 64,14, 1)
#                 my_oled.oled.line(4,62,120,62,1)
#                 my_oled.oled.show()
#                 my_oled.print_text("FORWARD", 0, 0)
                led_red.value(1)
                uart.write(b'AZAD2FYB')

            elif current == "B":
                print("BACKWARD")
#                 my_oled.oled.fill(0)
#                 my_oled.graphics.fill_circle(64,32,8,1)
#                 my_oled.graphics.fill_triangle(54,39, 74,40, 64,50, 1)
#                 my_oled.oled.line(4,62,120,62,1)
#                 my_oled.oled.show()
#                 my_oled.print_text("BACKWARD", 0, 0)
                led_red.value(1)
                uart.write(b'AZAD2BYB')

            elif current == "L":
                print("LEFT")
#                 my_oled.oled.fill(0)
#                 my_oled.graphics.fill_circle(64,32,8,1)
#                 my_oled.graphics.fill_triangle(56,22, 56,42, 46,32, 1)
#                 my_oled.oled.line(4,62,120,62,1)
#                 my_oled.oled.show()
#                 my_oled.print_text("LEFT", 0, 0)
                led_red.value(1)
                uart.write(b'AZAE1LYB')

            elif current == "R":
                print("RIGHT")
#                 my_oled.oled.fill(0)
#                 my_oled.graphics.fill_circle(64,32,8,1)
#                 my_oled.graphics.fill_triangle(72,22, 72,42, 82,32, 1)
#                 my_oled.oled.line(4,62,120,62,1)
#                 my_oled.oled.show()
#                 my_oled.print_text("RIGHT", 0, 0)
                led_red.value(1)
                uart.write(b'AZAE1RYB')
                
            elif current == "U" and current != "D":
                print("UP")
#                 my_oled.oled.fill(0)
#                 my_oled.graphics.fill_circle(64,32,8,1)
#                 my_oled.graphics.fill_triangle(54,24, 74,24, 64,14, 1)
#                 my_oled.oled.line(4,62,120,62,1)
#                 my_oled.oled.show()
#                 my_oled.print_text("CAMERA UP", 0, 0)
                led_red.value(1)
                uart.write(b'AZAG3UYB')

            elif current == "D" and current != "U":
                print("DOWN")
#                 my_oled.oled.fill(0)
#                 my_oled.graphics.fill_circle(64,32,8,1)
#                 my_oled.graphics.fill_triangle(54,39, 74,40, 64,50, 1)
#                 my_oled.oled.line(4,62,120,62,1)
#                 my_oled.oled.show()
#                 my_oled.print_text("CAMERA DOWN", 0, 0)
                led_red.value(1)
                uart.write(b'AZAG3DYB')
            
            elif current == "U" and current == "D":
                print("Pic")
                uart.write(b'AZAF4PYB')
            
            
            
            # Check if data is received
#             if complete == 1:
#                 #my_oled.oled.fill(0)
#                 
#                 if msg[3] == ord('M'):
#                     
#                     while msg[j+5] != ord('Y') and msg[j+6] != ord('B'):
#                         data[j] = msg[j+5]
#                         j+= 1
#                 
#                 text = data.decode('utf-8')
#                 print("ECHO:", text)
#                 
                #my_oled.print_text(data.decode('utf-8'), 0, 0)
                #my_oled.oled.show()
                #Write back uart msg if recieved from RX
                
                
                
                
                complete = 0
                j = 0


                
                
            previous_state = current
            
            
async def run_all():
    await asyncio.gather(receiver(), main())
 
asyncio.run(run_all())          
#asyncio.run(main()) 
        # Small sleep to yield CPU — IRQ handlers still update `direction.state`.
        #time.sleep(0.05)






